#Lista 1, exercício 3
n = float(input('Número: '))

if n < 0:
    print(f'{n*3}')
else:
    print(f'{n*2}')