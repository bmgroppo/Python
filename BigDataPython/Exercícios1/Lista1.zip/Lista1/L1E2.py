#Lista 1, exercício 2
A = int(input('Valor A: '))
B = int(input('Valor B: '))
C = 0

if A == B:
    C = A+B
else:
    C = A*B

print(C)