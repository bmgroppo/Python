#Lista 2, Exercício 10
num=int(input('Digite um número para saber sua tabuada: '))

for count in range (1,11):
    print(f'{num} x {count} = {num*count}')