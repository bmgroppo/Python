#Lista 2, Exercício 8
while True:
    n1=float(input('Digite o 1º número: '))
    n2=float(input('Digite o 2º número: '))

    print(f" A soma de {n1} + {n2} é: {n1+n2}")

    if (n1+n2)>15:
        break
    