#Lista 1, Exercício 1
A = float(input('Valor A: '))
B = float(input('Valor B: '))
C = float(input('Valor C: '))

if (A+B) > C:
    print(f'{A}+{B} = {A+B} que é maior que {C}')
else:
    print(f'{A}+{B} = {A+B} que é menor que {C}')
    